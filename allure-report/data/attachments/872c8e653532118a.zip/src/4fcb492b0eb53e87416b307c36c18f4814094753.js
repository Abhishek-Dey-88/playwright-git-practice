import { customtest as test, expect } from "../fixture/testfixtures.js";

test.describe.configure({ mode: "serial" });

test("@regressionbankregistartioncheck", async ({ pomanager, testdata }) => {
  const data = testdata.datafiller();
  const [username, password] = data.slice(8);

  await pomanager.gethomepage().goTo();
  await pomanager.gethomepage().clickonregisterlink();
  await pomanager.getregistrationpage().fillregistrationform(...data); //... is a spread operator
  await pomanager.getregistrationpage().clickonregisterbtn();
  await expect(
    pomanager.getregistrationpage().successregistrationmessage,
  ).toBeVisible();

  testdata.savecredentials(username, password);
});

test("@regressionlogin&openewaccountcheck", async ({ pomanager, testdata }) => {
  await pomanager.gethomepage().goTo();
  const { username, password } = testdata.getlatestcredentials();
  await pomanager.gethomepage().login(username, password);
  await pomanager.getloggedinpage().loggedinuser();
  await pomanager.getaccountdetails().clinkonopennewaccountlink();
  await pomanager.getaccountdetails().selectaccount();
  await pomanager.getaccountdetails().clickopenaccountbtn();
  const accountDetails = await pomanager
    .getaccountdetails()
    .getAccountOpenedText();
  console.log(`Account details:\n${accountDetails}`);
  await test.info().attach("account-details", {
    body: accountDetails,
    contentType: "text/plain",
  });
});

test("@regressiontransferfundscheck", async ({ pomanager, testdata }) => {
  await pomanager.gethomepage().goTo();
  const { username, password } = testdata.getlatestcredentials();
  await pomanager.gethomepage().login(username, password);
  await pomanager.getloggedinpage().loggedinuser();
  await pomanager.gettransferfunds().clickontransferfundslink();
  await pomanager.gettransferfunds().amounttextbox("515");
  await pomanager.gettransferfunds().clickontransferbtn();
  const transferSuccessMsg = await pomanager
    .gettransferfunds()
    .gettransfersuccessmsg();
  console.log(`Transfer Success Message:\n${transferSuccessMsg}`);
  await test.info().attach("transfer-success-message", {
    body: transferSuccessMsg,
    contentType: "text/plain",
  });
});